Dane temperatury ze stacji w �odzi
